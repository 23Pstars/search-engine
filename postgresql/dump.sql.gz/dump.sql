--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: host_directory; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE host_directory (
    id integer NOT NULL,
    address character varying,
    visited integer DEFAULT 1 NOT NULL,
    date date DEFAULT now()
);


ALTER TABLE public.host_directory OWNER TO winkom;

--
-- Name: TABLE host_directory; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE host_directory IS 'berisi daftar website sebagai awalan sebuah mesin pencari melakukan pencarian';


--
-- Name: host_directory_id_seq; Type: SEQUENCE; Schema: public; Owner: winkom
--

CREATE SEQUENCE host_directory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.host_directory_id_seq OWNER TO winkom;

--
-- Name: host_directory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: winkom
--

ALTER SEQUENCE host_directory_id_seq OWNED BY host_directory.visited;


--
-- Name: host_directory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winkom
--

SELECT pg_catalog.setval('host_directory_id_seq', 996, true);


--
-- Name: searched; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE searched (
    date date DEFAULT now(),
    keyword character varying
);


ALTER TABLE public.searched OWNER TO winkom;

--
-- Name: TABLE searched; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE searched IS 'berisi kata kunci yang pernah dicari';


--
-- Name: COLUMN searched.date; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON COLUMN searched.date IS 'tanggal pengaksesan';


--
-- Name: COLUMN searched.keyword; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON COLUMN searched.keyword IS 'kata kunci yang dicari';


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: winkom
--

CREATE SEQUENCE settings_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 100
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO winkom;

--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winkom
--

SELECT pg_catalog.setval('settings_id_seq', 9, true);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE settings (
    id integer DEFAULT nextval('settings_id_seq'::regclass) NOT NULL,
    option character varying(100) NOT NULL,
    value character varying(100)
);


ALTER TABLE public.settings OWNER TO winkom;

--
-- Name: TABLE settings; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE settings IS 'untuk menyimpan pengaturan sistem';


--
-- Name: COLUMN settings.id; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON COLUMN settings.id IS 'untuk ID tiap options value';


--
-- Name: COLUMN settings.option; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON COLUMN settings.option IS 'nama option';


--
-- Name: COLUMN settings.value; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON COLUMN settings.value IS 'nilai option';


--
-- Name: site_blocked_id_seq; Type: SEQUENCE; Schema: public; Owner: winkom
--

CREATE SEQUENCE site_blocked_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.site_blocked_id_seq OWNER TO winkom;

--
-- Name: site_blocked_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winkom
--

SELECT pg_catalog.setval('site_blocked_id_seq', 10, true);


--
-- Name: site_blocked; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE site_blocked (
    id integer DEFAULT nextval('site_blocked_id_seq'::regclass) NOT NULL,
    date date DEFAULT now(),
    link character varying(1000),
    status character varying(10) DEFAULT 'waiting'::character varying
);


ALTER TABLE public.site_blocked OWNER TO winkom;

--
-- Name: TABLE site_blocked; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE site_blocked IS 'daftar situs yang telah di blok';


--
-- Name: site_reported_id_seq; Type: SEQUENCE; Schema: public; Owner: winkom
--

CREATE SEQUENCE site_reported_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.site_reported_id_seq OWNER TO winkom;

--
-- Name: site_reported_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winkom
--

SELECT pg_catalog.setval('site_reported_id_seq', 13, true);


--
-- Name: site_reported; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE site_reported (
    id integer DEFAULT nextval('site_reported_id_seq'::regclass) NOT NULL,
    date date DEFAULT now(),
    link character varying(1000),
    reason character varying(1000),
    status character varying(10) DEFAULT 'waiting'::character varying,
    ip_sender character varying(15) NOT NULL
);


ALTER TABLE public.site_reported OWNER TO winkom;

--
-- Name: TABLE site_reported; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE site_reported IS 'daftar situs yang telah dilaporkan';


--
-- Name: site_submitted_id_seq; Type: SEQUENCE; Schema: public; Owner: winkom
--

CREATE SEQUENCE site_submitted_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.site_submitted_id_seq OWNER TO winkom;

--
-- Name: site_submitted_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winkom
--

SELECT pg_catalog.setval('site_submitted_id_seq', 15, true);


--
-- Name: site_submitted; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE site_submitted (
    id integer DEFAULT nextval('site_submitted_id_seq'::regclass) NOT NULL,
    date date DEFAULT now(),
    link character varying(1000),
    status character varying(10) DEFAULT 'waiting'::character varying,
    ip_sender character varying(15)
);


ALTER TABLE public.site_submitted OWNER TO winkom;

--
-- Name: TABLE site_submitted; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE site_submitted IS 'berisi daftar situs yang telah dikirimkan';


--
-- Name: websites_id_seq; Type: SEQUENCE; Schema: public; Owner: winkom
--

CREATE SEQUENCE websites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.websites_id_seq OWNER TO winkom;

--
-- Name: websites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winkom
--

SELECT pg_catalog.setval('websites_id_seq', 1990, true);


--
-- Name: websites; Type: TABLE; Schema: public; Owner: winkom; Tablespace: 
--

CREATE TABLE websites (
    id integer DEFAULT nextval('websites_id_seq'::regclass) NOT NULL,
    title character varying(500),
    link character varying(1000),
    visited integer DEFAULT 1,
    description text,
    keyword tsvector,
    date date DEFAULT now()
);


ALTER TABLE public.websites OWNER TO winkom;

--
-- Name: TABLE websites; Type: COMMENT; Schema: public; Owner: winkom
--

COMMENT ON TABLE websites IS 'data utama dari konten hasil pencarian, berisi daftar website yang pernah dicari';


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: winkom
--

ALTER TABLE host_directory ALTER COLUMN id SET DEFAULT nextval('host_directory_id_seq'::regclass);


--
-- Data for Name: host_directory; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO host_directory VALUES (975, 'http://localhost/installed/joomla/', 1, '2013-06-10');
INSERT INTO host_directory VALUES (976, 'http://localhost/references/codex-wordpress/codex.wordpress.org/', 1, '2013-06-10');
INSERT INTO host_directory VALUES (977, 'http://localhost/references/php-manual/', 1, '2013-06-10');
INSERT INTO host_directory VALUES (978, 'http://localhost/references/w3schools/www.w3schools.com/', 1, '2013-06-10');
INSERT INTO host_directory VALUES (979, 'http://localhost/references/android-docs/', 1, '2013-06-10');
INSERT INTO host_directory VALUES (980, 'http://lists.automattic.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (981, 'http://doku.wordpress-deutschland.org', 1, '2013-06-10');
INSERT INTO host_directory VALUES (982, 'http://dokumentacio.word-press.hu', 1, '2013-06-10');
INSERT INTO host_directory VALUES (983, 'http://wpdocs.sourceforge.jp', 1, '2013-06-10');
INSERT INTO host_directory VALUES (984, 'http://wp-support.se', 1, '2013-06-10');
INSERT INTO host_directory VALUES (985, 'http://codex.wordthai.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (986, 'http://wordpress.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (987, 'http://android-developers.blogspot.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (988, 'http://www.android.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (989, 'http://market.android.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (990, 'http://source.android.com', 1, '2013-06-10');
INSERT INTO host_directory VALUES (991, 'http://creativecommons.org', 1, '2013-06-10');
INSERT INTO host_directory VALUES (992, 'http://wordpress.tv', 1, '2013-06-10');
INSERT INTO host_directory VALUES (993, 'http://central.wordcamp.org', 1, '2013-06-10');
INSERT INTO host_directory VALUES (994, 'http://jobs.wordpress.net', 1, '2013-06-10');
INSERT INTO host_directory VALUES (995, 'http://ma.tt', 1, '2013-06-10');
INSERT INTO host_directory VALUES (996, 'http://www.facebook.com', 1, '2013-06-10');


--
-- Data for Name: searched; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO searched VALUES ('2013-04-10', 'wordpress');
INSERT INTO searched VALUES ('2013-04-10', 'wordpress');
INSERT INTO searched VALUES ('2013-04-10', 'joomla');
INSERT INTO searched VALUES ('2013-04-10', 'google');
INSERT INTO searched VALUES ('2013-04-10', 'facebook');
INSERT INTO searched VALUES ('2013-04-10', 'facebook');
INSERT INTO searched VALUES ('2013-04-10', 'facebook');
INSERT INTO searched VALUES ('2013-04-10', 'facebook');
INSERT INTO searched VALUES ('2013-04-10', 'chrome');
INSERT INTO searched VALUES ('2013-04-10', 'linux');
INSERT INTO searched VALUES ('2013-04-10', 'unram');
INSERT INTO searched VALUES ('2013-03-10', 'facebook');
INSERT INTO searched VALUES ('2013-03-10', 'facebook');
INSERT INTO searched VALUES ('2013-03-10', 'google');
INSERT INTO searched VALUES ('2013-03-10', 'linux');
INSERT INTO searched VALUES ('2013-03-10', 'wordpress');
INSERT INTO searched VALUES ('2013-03-10', 'wordpress');
INSERT INTO searched VALUES ('2013-03-10', 'wordpress');
INSERT INTO searched VALUES ('2013-03-10', 'wordpress');
INSERT INTO searched VALUES ('2013-03-10', 'wordpress');
INSERT INTO searched VALUES ('2013-04-11', 'facebook');
INSERT INTO searched VALUES ('2013-05-04', 'zaf');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress ');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress blog');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress ');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress blog');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress ');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress');
INSERT INTO searched VALUES ('2013-05-07', 'wordpress');
INSERT INTO searched VALUES ('2013-05-07', 'facebook');
INSERT INTO searched VALUES ('2013-05-10', 'ubuntu');
INSERT INTO searched VALUES ('2013-05-10', 'ubuntu');
INSERT INTO searched VALUES ('2013-05-10', 'ubuntu');
INSERT INTO searched VALUES ('2013-05-10', 'ubuntu');
INSERT INTO searched VALUES ('2013-05-10', 'wordpress');
INSERT INTO searched VALUES ('2013-05-10', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress ');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'ubuntu');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'unram');
INSERT INTO searched VALUES ('2013-05-18', 'unram');
INSERT INTO searched VALUES ('2013-05-18', 'universitas mataram');
INSERT INTO searched VALUES ('2013-05-18', 'universitas mataram');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-18', 'wordpress');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'android');
INSERT INTO searched VALUES ('2013-05-20', 'iOS');
INSERT INTO searched VALUES ('2013-05-28', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'wordpress');
INSERT INTO searched VALUES ('2013-06-10', 'wordpress');
INSERT INTO searched VALUES ('2013-06-10', 'wordpress');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'asdfsdfsdfa');
INSERT INTO searched VALUES ('2013-06-10', 'android');
INSERT INTO searched VALUES ('2013-06-10', 'assdfffffff');


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO settings VALUES (1, 'username', 'Zaf');
INSERT INTO settings VALUES (2, 'password', 'ahmad');
INSERT INTO settings VALUES (3, 'max_deep', '5');
INSERT INTO settings VALUES (4, 'links_per_page', '10');
INSERT INTO settings VALUES (7, 'host_directory_per_process', '30');
INSERT INTO settings VALUES (5, 'max_links_received', '50');
INSERT INTO settings VALUES (6, 'max_links_crawled', '100');
INSERT INTO settings VALUES (8, 'min_percentage_match', '25');
INSERT INTO settings VALUES (9, 'timeout_searching', '180');


--
-- Data for Name: site_blocked; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO site_blocked VALUES (6, '2013-05-07', 'http://localhost/references/codex-wordpress/codex.wordpress.org/FAQ_New_To_WordPress.html', 'waiting');
INSERT INTO site_blocked VALUES (7, '2013-05-28', 'http://localhost/references/android-docs/videos/index.html', 'waiting');
INSERT INTO site_blocked VALUES (8, '2013-06-10', 'http://localhost/references/codex-wordpress/codex.wordpress.org/FAQ_Developer_Documentation.html', 'waiting');
INSERT INTO site_blocked VALUES (9, '2013-06-10', 'http://localhost/references/android-docs/videos/index.html', 'waiting');
INSERT INTO site_blocked VALUES (10, '2013-06-10', 'http://localhost/references/android-docs/resources/dashboard/platform-versions.html', 'waiting');


--
-- Data for Name: site_reported; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO site_reported VALUES (1, '2013-04-04', 'http://blackberry.wordpress.org', 'test ngelapor', 'accepted', '::1');
INSERT INTO site_reported VALUES (5, '2013-04-07', 'http://localhost/references/codex-wordpress/codex.wordpress.org/Moving_WordPress.html', 'test ngelapor', 'waiting', '::1');
INSERT INTO site_reported VALUES (9, '2013-04-08', 'http://localhost/references/codex-wordpress/codex.wordpress.org/Plugins.html', 'sdfgdsfgdgffdgdfgdf', 'accepted', '::1');
INSERT INTO site_reported VALUES (7, '2013-04-08', 'http://localhost/references/codex-wordpress/codex.wordpress.org/FAQ_New_To_WordPress.html', 'situs anu', 'accepted', '::1');
INSERT INTO site_reported VALUES (10, '2013-05-28', 'http://localhost/references/android-docs/videos/index.html', 'alasan', 'accepted', '::1');
INSERT INTO site_reported VALUES (11, '2013-05-28', 'http://localhost/references/android-docs/offline.html', 'alasan tertentu', 'waiting', '::1');
INSERT INTO site_reported VALUES (8, '2013-04-08', 'http://localhost/references/codex-wordpress/codex.wordpress.org/FAQ_Developer_Documentation.html', 'sdfg', 'accepted', '::1');
INSERT INTO site_reported VALUES (12, '2013-06-10', 'http://localhost/references/android-docs/videos/index.html', 'tes laporkan', 'accepted', '::1');
INSERT INTO site_reported VALUES (13, '2013-06-10', 'http://localhost/references/android-docs/resources/dashboard/platform-versions.html', 'alasan', 'accepted', '::1');


--
-- Data for Name: site_submitted; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO site_submitted VALUES (5, '2013-03-29', 'http://ftunram.ac.id', 'accepted', '::1');
INSERT INTO site_submitted VALUES (6, '2013-03-29', 'http://ftunram.ac.id/', 'accepted', '::1');
INSERT INTO site_submitted VALUES (13, '2013-05-07', 'http://ftunram.ac.id', 'waiting', '::1');
INSERT INTO site_submitted VALUES (14, '2013-05-28', 'http://unram.ac.id', 'waiting', '::1');
INSERT INTO site_submitted VALUES (15, '2013-06-10', 'http://www.website.com', 'waiting', '::1');


--
-- Data for Name: websites; Type: TABLE DATA; Schema: public; Owner: winkom
--

INSERT INTO websites VALUES (1983, 'Android Developers', 'http://localhost/references/android-docs/', 1, 'Android Developers', '''android'':1,3 ''develop'':2,4', '2013-06-10');
INSERT INTO websites VALUES (1984, 'Android Developers', 'http://localhost/references/android-docs/index.html', 1, 'Android Developers', '''android'':1,3 ''develop'':2,4', '2013-06-10');
INSERT INTO websites VALUES (1985, 'Welcome | Android Developers', 'http://localhost/references/android-docs/offline.html', 1, 'Welcome | Android Developers', '''android'':2,5 ''develop'':3,6 ''welcom'':1,4', '2013-06-10');
INSERT INTO websites VALUES (1986, 'Developer Resources | Android Developers', 'http://localhost/references/android-docs/resources/index.html', 1, 'Developer Resources | Android Developers', '''android'':3,7 ''develop'':1,4,5,8 ''resourc'':2,6', '2013-06-10');
INSERT INTO websites VALUES (1987, 'Android SDK | Android Developers', 'http://localhost/references/android-docs/sdk/index.html', 1, 'Android SDK | Android Developers', '''android'':1,3,5,7 ''develop'':4,8 ''sdk'':2,6', '2013-06-10');
INSERT INTO websites VALUES (1988, 'Package Index - Android SDK | Android Developers', 'http://localhost/references/android-docs/reference/packages.html', 1, 'Package Index - Android SDK | Android Developers', '''android'':3,5,9,11 ''develop'':6,12 ''index'':2,8 ''packag'':1,7 ''sdk'':4,10', '2013-06-10');
INSERT INTO websites VALUES (1989, 'Content License | Android Developers', 'http://localhost/references/android-docs/license.html', 1, 'Content License | Android Developers', '''android'':3,7 ''content'':1,5 ''develop'':4,8 ''licens'':2,6', '2013-06-10');


--
-- Name: dir_pkey; Type: CONSTRAINT; Schema: public; Owner: winkom; Tablespace: 
--

ALTER TABLE ONLY websites
    ADD CONSTRAINT dir_pkey PRIMARY KEY (id);

ALTER TABLE websites CLUSTER ON dir_pkey;


--
-- Name: hd_pkey; Type: CONSTRAINT; Schema: public; Owner: winkom; Tablespace: 
--

ALTER TABLE ONLY host_directory
    ADD CONSTRAINT hd_pkey PRIMARY KEY (id);


--
-- Name: settings_pkey; Type: CONSTRAINT; Schema: public; Owner: winkom; Tablespace: 
--

ALTER TABLE ONLY settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (option);


--
-- Name: site_blocked_pkey; Type: CONSTRAINT; Schema: public; Owner: winkom; Tablespace: 
--

ALTER TABLE ONLY site_blocked
    ADD CONSTRAINT site_blocked_pkey PRIMARY KEY (id);


--
-- Name: site_reported_pkey; Type: CONSTRAINT; Schema: public; Owner: winkom; Tablespace: 
--

ALTER TABLE ONLY site_reported
    ADD CONSTRAINT site_reported_pkey PRIMARY KEY (id);


--
-- Name: site_submitted_pkey; Type: CONSTRAINT; Schema: public; Owner: winkom; Tablespace: 
--

ALTER TABLE ONLY site_submitted
    ADD CONSTRAINT site_submitted_pkey PRIMARY KEY (id);


--
-- Name: id_pkey; Type: INDEX; Schema: public; Owner: winkom; Tablespace: 
--

CREATE UNIQUE INDEX id_pkey ON host_directory USING btree (id);

ALTER TABLE host_directory CLUSTER ON id_pkey;


--
-- Name: websites_keyword; Type: INDEX; Schema: public; Owner: winkom; Tablespace: 
--

CREATE INDEX websites_keyword ON websites USING gin (keyword);


--
-- Name: websites_link; Type: INDEX; Schema: public; Owner: winkom; Tablespace: 
--

CREATE INDEX websites_link ON websites USING btree (link);


--
-- Name: websites_update; Type: TRIGGER; Schema: public; Owner: winkom
--

CREATE TRIGGER websites_update
    BEFORE INSERT OR UPDATE ON websites
    FOR EACH ROW
    EXECUTE PROCEDURE tsvector_update_trigger('keyword', 'pg_catalog.english', 'title', 'description');


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

